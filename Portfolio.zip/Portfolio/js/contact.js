function Switch () {
    let darkmode = document.getElementById("darkmodelink");
    if (darkmode) {
        darkmode.remove();
    } else {
        let element = document.createElement("link");
        element.rel = "stylesheet";
        element.href = "themecss/themecontact.css";
        element.id = "darkmodelink";
        document.head.appendChild(element);
    }
}

