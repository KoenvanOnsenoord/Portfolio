<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=portfolio","root", "");
    if(isset ($_POST["sumbit"])) {
     $statement = $db->prepare("INSERT INTO contact (name, email, message) values(?, ?, ?)");
     $statement->execute([$_POST["name"], $_POST["email"],$_POST["message"]]);
    }
} catch(PDOException $e) {
    die("Error!: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="language" content="nl" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Koen van Onsenoord" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Portfolio Contact</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
      integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" type="text/css" href="css/contact.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap"
      rel="stylesheet"
    />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link
      rel="stylesheet"
      href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    />
  </head>
  <body>
    <header>
      <nav>
        <input type="checkbox" id="check" />
        <label for="check" class="checkbtn">
          <i class="fas fa-bars"></i>
        </label>
        <label class="logo">Koen</label>
        <ul>
          <li>
            <a href="#"><span onclick="Switch()">Switch Theme</span></a>
          </li>
          <li><a href="home.html">Home</a></li>
          <li><a href="skills.html">Skills</a></li>
          <li><a href="projects.html">Projects</a></li>
          <li><a class="active" href="contact.html">Contact</a></li>
        </ul>
      </nav>
    </header>
    <main>
      <div  class="contact-form">
        <form name="formulier" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
          <h1>Contact Me</h1>
          <div class="txtb">
            <label>Naam :</label>
            <input type="text" name="name" value="" placeholder="Enter Your Name" required>
          </div>
      
          <div class="txtb">
            <label>Email :</label>
            <input type="email" name="email" value="" placeholder="Enter Your Email" required>
          </div>
          <div class="txtb">
            <label>Bericht :</label>
            <textarea name="message"></textarea required>
          </div>
          <input class="btn" type="submit" name="sumbit" value="Send">
        </div>
      </form>
      <div class="contact-info">
        <h4>Contact</h4>
        <p><span class="fa fa-phone"></span> +31 6 58855581</p>
        <p><span class="fa fa-envelope"></span> koenvanonsenoord@gmail.com</p>
        <p>
          <i class="fab fa-github"
            ><a class="a" href="https://github.com/KoenvanOnsenoord">
              Github</a
            ></i
          >
        </p>
        <p>
          <i class="fab fa-linkedin-in"
            ><a
              class="a"
              href="https://www.linkedin.com/in/koen-van-onsenoord-4843aa1a1/"
            >
              Linkedin</a
            ></i
          >
        </p>
      </div>
    </main>
    <footer></footer>
    <script
      src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
      integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
      crossorigin="anonymous"
    ></script>
    <script src="js/contact.js"></script>
  </body>
</html>
